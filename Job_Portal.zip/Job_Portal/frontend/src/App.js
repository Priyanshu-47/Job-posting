import logo from './logo.svg';
import './App.css';
import Home from './pages/Home';

function App() {
  return (
    <div className="bg-gray-100 min-h-screen">
      <Home></Home>
      {/* <h1 className="text-4xl font-bold text-primary">
        Welcome to the Job Portal App!
      </h1> */}
      
    </div>
  );
}

export default App;
